# CasaCraft Generator v2

Prototipo Android con interfaz renovada:
- Pantalla principal con encabezado.
- Seed y coordenadas X/Y/Z.
- Selector de 5 estilos de casa.
- Control de tamaño.
- Vista previa del plano.
- Botón de generación.
- Botón preparado para la futura exportación .mcpack.

Esta versión es un prototipo visual/funcional. La adaptación real a la seed y la exportación final deben integrarse y probarse antes de publicación.
